-- =============================================================================
-- 03_trends_and_moving_averages.sql
-- Monthly trends, rolling revenue, and revenue growth rates
-- =============================================================================

-- Q1: Monthly revenue and cost trend
WITH monthly AS (
    SELECT
        DATE_TRUNC('month', start_date) AS month,
        SUM(revenue) AS monthly_revenue,
        SUM(cost)    AS monthly_cost
    FROM campaigns
    GROUP BY 1
)
SELECT
    month,
    monthly_revenue,
    monthly_cost,
    monthly_revenue - monthly_cost AS net_profit,
    ROUND((monthly_revenue - monthly_cost) / NULLIF(monthly_cost, 0), 4) AS monthly_roi
FROM monthly
ORDER BY month;

-- Q2: 3-month rolling average revenue (moving average via window function)
WITH monthly AS (
    SELECT
        DATE_TRUNC('month', start_date) AS month,
        SUM(revenue) AS monthly_revenue
    FROM campaigns
    GROUP BY 1
)
SELECT
    month,
    monthly_revenue,
    ROUND(AVG(monthly_revenue) OVER (
        ORDER BY month
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 2) AS rolling_3mo_avg_revenue
FROM monthly
ORDER BY month;

-- Q3: Month-over-month revenue growth rate using LAG()
WITH monthly AS (
    SELECT
        DATE_TRUNC('month', start_date) AS month,
        SUM(revenue) AS monthly_revenue
    FROM campaigns
    GROUP BY 1
)
SELECT
    month,
    monthly_revenue,
    LAG(monthly_revenue) OVER (ORDER BY month) AS prev_month_revenue,
    ROUND(
        100.0 * (monthly_revenue - LAG(monthly_revenue) OVER (ORDER BY month))
        / NULLIF(LAG(monthly_revenue) OVER (ORDER BY month), 0), 2
    ) AS mom_growth_pct
FROM monthly
ORDER BY month;

-- Q4: Cumulative revenue (running total) per channel
SELECT
    channel,
    DATE_TRUNC('month', start_date) AS month,
    SUM(revenue) AS monthly_revenue,
    SUM(SUM(revenue)) OVER (
        PARTITION BY channel ORDER BY DATE_TRUNC('month', start_date)
    ) AS cumulative_revenue
FROM campaigns
GROUP BY channel, DATE_TRUNC('month', start_date)
ORDER BY channel, month;

-- Q5: Customer acquisition trend by month and top acquisition channel
SELECT
    DATE_TRUNC('month', signup_date) AS signup_month,
    traffic_source,
    COUNT(*) AS new_customers
FROM customers
GROUP BY 1, 2
ORDER BY 1, new_customers DESC;
