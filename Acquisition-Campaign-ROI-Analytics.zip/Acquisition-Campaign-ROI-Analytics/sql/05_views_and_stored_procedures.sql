-- =============================================================================
-- 05_views_and_stored_procedures.sql
-- Reusable views and a stored procedure for monthly ROI refresh
-- =============================================================================

-- View: Channel performance summary (feeds Power BI / Tableau directly)
CREATE OR REPLACE VIEW vw_channel_performance AS
SELECT
    channel,
    COUNT(*)                                      AS campaigns_run,
    SUM(budget)                                   AS total_budget,
    SUM(cost)                                     AS total_cost,
    SUM(revenue)                                  AS total_revenue,
    SUM(conversions)                              AS total_conversions,
    ROUND((SUM(revenue) - SUM(cost)) / NULLIF(SUM(cost), 0), 4) AS roi,
    ROUND(SUM(revenue) / NULLIF(SUM(cost), 0), 4)               AS roas,
    ROUND(SUM(cost) / NULLIF(SUM(conversions), 0), 2)           AS cac
FROM campaigns
GROUP BY channel;

-- View: Monthly executive summary
CREATE OR REPLACE VIEW vw_monthly_executive_summary AS
SELECT
    DATE_TRUNC('month', start_date) AS month,
    SUM(revenue)  AS total_revenue,
    SUM(cost)     AS total_cost,
    SUM(revenue) - SUM(cost) AS net_profit,
    ROUND((SUM(revenue) - SUM(cost)) / NULLIF(SUM(cost), 0), 4) AS roi,
    COUNT(*) AS campaigns_run
FROM campaigns
GROUP BY 1
ORDER BY 1;

-- Stored Procedure (PostgreSQL): refresh a materialized summary table
-- used by the BI layer on a nightly schedule.
CREATE TABLE IF NOT EXISTS channel_performance_snapshot AS
SELECT * FROM vw_channel_performance WITH NO DATA;

CREATE OR REPLACE PROCEDURE refresh_channel_performance_snapshot()
LANGUAGE plpgsql
AS $$
BEGIN
    TRUNCATE TABLE channel_performance_snapshot;
    INSERT INTO channel_performance_snapshot
    SELECT * FROM vw_channel_performance;

    RAISE NOTICE 'channel_performance_snapshot refreshed at %', now();
END;
$$;

-- Usage:
-- CALL refresh_channel_performance_snapshot();

-- Trigger example: automatically flag high-refund transactions for review
CREATE TABLE IF NOT EXISTS flagged_transactions (
    transaction_id VARCHAR(15),
    reason         VARCHAR(120),
    flagged_at     TIMESTAMP DEFAULT now()
);

CREATE OR REPLACE FUNCTION fn_flag_refund()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.refund = 1 AND NEW.purchase_amount > 300 THEN
        INSERT INTO flagged_transactions (transaction_id, reason)
        VALUES (NEW.transaction_id, 'High-value refund requires review');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_flag_refund ON transactions;
CREATE TRIGGER trg_flag_refund
AFTER INSERT ON transactions
FOR EACH ROW
EXECUTE FUNCTION fn_flag_refund();
