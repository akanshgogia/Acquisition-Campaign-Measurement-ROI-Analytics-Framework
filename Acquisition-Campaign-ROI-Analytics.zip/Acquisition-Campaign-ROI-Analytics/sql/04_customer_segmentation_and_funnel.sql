-- =============================================================================
-- 04_customer_segmentation_and_funnel.sql
-- Customer segmentation, geography/device performance, and conversion funnel
-- =============================================================================

-- Q1: Customer segment performance summary
SELECT
    customer_segment,
    COUNT(*)                    AS customers,
    ROUND(AVG(lifetime_value),2) AS avg_ltv,
    ROUND(SUM(lifetime_value),2) AS total_ltv,
    ROUND(AVG(total_orders),2)   AS avg_orders
FROM customers
GROUP BY customer_segment
ORDER BY total_ltv DESC;

-- Q2: RFM-style ranking of customers within each segment (window function)
SELECT
    customer_id,
    customer_segment,
    lifetime_value,
    NTILE(4) OVER (PARTITION BY customer_segment ORDER BY lifetime_value DESC) AS ltv_quartile,
    RANK()   OVER (PARTITION BY customer_segment ORDER BY lifetime_value DESC) AS ltv_rank_in_segment
FROM customers;

-- Q3: Geography performance (best countries by total and average LTV)
SELECT
    country,
    COUNT(*) AS customers,
    ROUND(AVG(lifetime_value), 2) AS avg_ltv,
    ROUND(SUM(lifetime_value), 2) AS total_ltv
FROM customers
GROUP BY country
ORDER BY total_ltv DESC;

-- Q4: Device performance -- conversion behavior by device type
SELECT
    c.device,
    COUNT(DISTINCT t.transaction_id)              AS total_transactions,
    ROUND(AVG(t.purchase_amount), 2)               AS avg_order_value,
    ROUND(SUM(t.purchase_amount), 2)               AS total_revenue
FROM customers c
JOIN transactions t ON c.customer_id = t.customer_id
GROUP BY c.device
ORDER BY total_revenue DESC;

-- Q5: Acquisition -> Conversion funnel (channel level)
SELECT
    channel,
    SUM(impressions)  AS stage_impressions,
    SUM(clicks)        AS stage_clicks,
    SUM(conversions)   AS stage_conversions,
    ROUND(100.0 * SUM(clicks) / NULLIF(SUM(impressions), 0), 3)  AS click_through_pct,
    ROUND(100.0 * SUM(conversions) / NULLIF(SUM(clicks), 0), 3)  AS conversion_pct
FROM campaigns
GROUP BY channel
ORDER BY stage_impressions DESC;

-- Q6: Customer segmentation via a reusable VIEW
CREATE OR REPLACE VIEW vw_customer_value_tiers AS
SELECT
    customer_id,
    customer_segment,
    country,
    device,
    lifetime_value,
    CASE
        WHEN lifetime_value >= 500 THEN 'Platinum'
        WHEN lifetime_value >= 250 THEN 'Gold'
        WHEN lifetime_value >= 100 THEN 'Silver'
        ELSE 'Bronze'
    END AS value_tier
FROM customers;

SELECT value_tier, COUNT(*) AS customers, ROUND(AVG(lifetime_value),2) AS avg_ltv
FROM vw_customer_value_tiers
GROUP BY value_tier
ORDER BY avg_ltv DESC;
