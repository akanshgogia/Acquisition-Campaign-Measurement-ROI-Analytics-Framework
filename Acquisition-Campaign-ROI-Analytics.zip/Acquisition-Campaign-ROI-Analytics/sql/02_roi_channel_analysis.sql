-- =============================================================================
-- 02_roi_channel_analysis.sql
-- Channel-level ROI, ROAS, CAC, and ranking analysis
-- =============================================================================

-- Q1: Overall ROI, ROAS, and CAC by channel
SELECT
    channel,
    COUNT(*)                                   AS campaigns_run,
    SUM(cost)                                  AS total_cost,
    SUM(revenue)                               AS total_revenue,
    ROUND(SUM(conversions))                    AS total_conversions,
    ROUND((SUM(revenue) - SUM(cost)) / NULLIF(SUM(cost), 0), 4)   AS overall_roi,
    ROUND(SUM(revenue) / NULLIF(SUM(cost), 0), 4)                  AS overall_roas,
    ROUND(SUM(cost) / NULLIF(SUM(conversions), 0), 2)              AS cac
FROM campaigns
GROUP BY channel
ORDER BY overall_roi DESC;

-- Q2: Channel ranking using window functions (RANK, DENSE_RANK)
WITH channel_agg AS (
    SELECT
        channel,
        SUM(revenue) - SUM(cost) AS net_profit,
        SUM(revenue) / NULLIF(SUM(cost), 0) AS roas
    FROM campaigns
    GROUP BY channel
)
SELECT
    channel,
    net_profit,
    roas,
    RANK()       OVER (ORDER BY net_profit DESC) AS profit_rank,
    DENSE_RANK() OVER (ORDER BY roas DESC)        AS roas_rank
FROM channel_agg
ORDER BY profit_rank;

-- Q3: Top 20 campaigns by ROI (with CASE WHEN performance tiering)
SELECT
    campaign_id,
    campaign_name,
    channel,
    roi,
    roas,
    revenue,
    cost,
    CASE
        WHEN roi >= 5   THEN 'Excellent'
        WHEN roi >= 2   THEN 'Strong'
        WHEN roi >= 0.5 THEN 'Moderate'
        WHEN roi >= 0   THEN 'Weak'
        ELSE 'Loss-Making'
    END AS performance_tier
FROM campaigns
ORDER BY roi DESC
LIMIT 20;

-- Q4: Campaigns recommended for pause (loss-making, statistically significant spend)
SELECT
    campaign_id, campaign_name, channel, cost, revenue, roi
FROM campaigns
WHERE roi < 0
  AND cost > (SELECT AVG(cost) FROM campaigns)   -- only flag material spend
ORDER BY roi ASC
LIMIT 50;

-- Q5: Budget allocation recommendation — channel ROI vs. share of total spend
WITH channel_stats AS (
    SELECT
        channel,
        SUM(cost) AS total_cost,
        SUM(revenue) AS total_revenue,
        SUM(revenue) - SUM(cost) AS net_profit
    FROM campaigns
    GROUP BY channel
),
totals AS (
    SELECT SUM(total_cost) AS grand_total_cost FROM channel_stats
)
SELECT
    cs.channel,
    cs.total_cost,
    ROUND(100.0 * cs.total_cost / t.grand_total_cost, 2) AS pct_of_total_spend,
    ROUND(cs.net_profit / NULLIF(cs.total_cost, 0), 4)   AS roi,
    CASE
        WHEN cs.net_profit / NULLIF(cs.total_cost, 0) >
             (SELECT AVG(net_profit / NULLIF(total_cost, 0)) FROM channel_stats) * 1.15
            THEN 'Increase Budget'
        WHEN cs.net_profit / NULLIF(cs.total_cost, 0) <
             (SELECT AVG(net_profit / NULLIF(total_cost, 0)) FROM channel_stats) * 0.85
            THEN 'Decrease Budget'
        ELSE 'Maintain'
    END AS recommendation
FROM channel_stats cs
CROSS JOIN totals t
ORDER BY roi DESC;
