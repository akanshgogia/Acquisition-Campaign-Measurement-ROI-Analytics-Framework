-- =============================================================================
-- 01_schema.sql
-- Schema definition for the Acquisition Campaign ROI Analytics warehouse.
-- Target: PostgreSQL 14+ (fully compatible with minor tweaks on MySQL/Snowflake)
-- =============================================================================

DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS campaigns;

CREATE TABLE campaigns (
    campaign_id       VARCHAR(15)   PRIMARY KEY,
    campaign_name     VARCHAR(120)  NOT NULL,
    channel           VARCHAR(50)   NOT NULL,
    campaign_type     VARCHAR(50),
    start_date        DATE          NOT NULL,
    end_date          DATE          NOT NULL,
    budget            NUMERIC(12,2),
    impressions        BIGINT,
    clicks             BIGINT,
    ctr                NUMERIC(8,4),
    cpc                NUMERIC(8,2),
    conversions        INT,
    conversion_rate    NUMERIC(8,4),
    revenue            NUMERIC(14,2),
    cost               NUMERIC(14,2),
    roi                NUMERIC(10,4),
    roas               NUMERIC(10,4)
);

CREATE TABLE customers (
    customer_id       VARCHAR(15)   PRIMARY KEY,
    age               INT,
    gender            VARCHAR(20),
    city              VARCHAR(80),
    country           VARCHAR(80),
    device            VARCHAR(20),
    traffic_source    VARCHAR(50),
    customer_segment  VARCHAR(30),
    signup_date       DATE,
    purchase_date     DATE,
    lifetime_value    NUMERIC(12,2),
    total_orders      INT
);

CREATE TABLE transactions (
    transaction_id    VARCHAR(15)   PRIMARY KEY,
    customer_id       VARCHAR(15)   REFERENCES customers(customer_id),
    campaign_id       VARCHAR(15)   REFERENCES campaigns(campaign_id),
    purchase_amount   NUMERIC(12,2),
    profit            NUMERIC(12,2),
    order_date        DATE,
    refund            SMALLINT,
    coupon_used       SMALLINT
);

-- Indexes to accelerate the analytical queries in this project
CREATE INDEX idx_campaigns_channel      ON campaigns(channel);
CREATE INDEX idx_campaigns_start_date   ON campaigns(start_date);
CREATE INDEX idx_customers_segment      ON customers(customer_segment);
CREATE INDEX idx_customers_country      ON customers(country);
CREATE INDEX idx_transactions_campaign  ON transactions(campaign_id);
CREATE INDEX idx_transactions_customer  ON transactions(customer_id);
CREATE INDEX idx_transactions_order_dt  ON transactions(order_date);

-- Load data (psql \copy example — adjust path for your environment)
-- \copy campaigns    FROM 'data/raw/campaigns.csv'    WITH (FORMAT csv, HEADER true);
-- \copy customers    FROM 'data/raw/customers.csv'    WITH (FORMAT csv, HEADER true);
-- \copy transactions FROM 'data/raw/transactions.csv' WITH (FORMAT csv, HEADER true);
