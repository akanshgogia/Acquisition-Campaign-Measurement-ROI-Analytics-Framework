# Tableau Dashboard Specification

**Data Source:** Extract from `data/processed/master_table.csv` + `campaigns_clean.csv` (live/extract hybrid)
**Workbook:** `Acquisition_ROI_Analytics.twbx`

---

## Data Connections
- `campaigns_clean.csv` (primary)
- `customers_clean.csv`
- `transactions_clean.csv`
- Relationships (Tableau's relationship model, not a physical join) on `campaign_id` and `customer_id`

---

## Calculated Fields

```
// ROI
ROI = ([Revenue] - [Cost]) / [Cost]

// ROAS
ROAS = [Revenue] / [Cost]

// CAC
CAC = [Cost] / [Conversions]

// Performance Tier
Performance Tier =
IF [ROI] >= 5 THEN "Excellent"
ELSEIF [ROI] >= 2 THEN "Strong"
ELSEIF [ROI] >= 0.5 THEN "Moderate"
ELSEIF [ROI] >= 0 THEN "Weak"
ELSE "Loss-Making"
END

// MoM Revenue Growth
MoM Growth % =
(SUM([Revenue]) - LOOKUP(SUM([Revenue]), -1)) / ABS(LOOKUP(SUM([Revenue]), -1))

// Rolling 3-Month Revenue
Rolling 3Mo Revenue = WINDOW_AVG(SUM([Revenue]), -2, 0)

// Budget Recommendation
Budget Recommendation =
IF [ROI] > WINDOW_AVG([ROI]) * 1.15 THEN "Increase Budget"
ELSEIF [ROI] < WINDOW_AVG([ROI]) * 0.85 THEN "Decrease Budget"
ELSE "Maintain"
END
```

---

## Parameters
- **Top N Campaigns** (integer, 5–50, default 15) — drives the Top-N campaign bar chart
- **Metric Selector** (string list: ROI / ROAS / CAC / Revenue) — swaps the measure driving several charts via a parameter-based calculated field
- **Budget Shift %** (0–30%, default 10%) — feeds the budget-optimization "what-if" sheet

## Filters
- Date Range (start_date), Channel, Campaign Type, Customer Segment, Country, Device
- Context filter on Date Range to improve performance of dependent calculations

---

## Dashboard 1 — Executive Overview
- KPI tiles (Revenue, Cost, Net Profit, ROI, ROAS, CAC) using BANs (Big Ass Numbers)
- Dual-axis line chart: Revenue & Cost over time
- Map: Revenue by Country (filled map)
- Donut: Revenue share by channel

## Dashboard 2 — Campaign Performance
- Bar chart: Top N campaigns by selected metric (uses "Top N Campaigns" + "Metric Selector" parameters)
- Highlight table: Campaign x Performance Tier
- Scatter: CTR vs Conversion Rate sized by Revenue, colored by Channel

## Dashboard 3 — Customer Analytics
- Treemap: LTV by Segment x Country
- Bar: Average LTV by Device
- Histogram: Customer Age distribution

## Dashboard 4 — Marketing ROI
- Heatmap: Channel x Month (color = ROI)
- Bar: ROAS and CAC by channel (dual chart, synchronized axis)
- Trend line: Cumulative revenue per channel

## Dashboard 5 — Budget Optimization
- Bar-in-bar: Current vs. Recommended Budget by channel
- Table: Recommendation with "Budget Shift %" parameter control
- Dynamic profit-impact BAN, recalculated live from the parameter

## Dashboard 6 — Forecasting
- Trend line with Tableau's built-in forecast (Analytics pane → Forecast, exponential smoothing model)
- Forecast confidence-band shading
- Table: Forecasted revenue by channel for next quarter

---

## Drill-Through / Actions
- **Filter action:** Clicking a channel on Dashboard 1 filters Dashboards 2–4 to that channel.
- **URL action:** Clicking a campaign row opens a linked campaign-detail sheet.
- **Highlight action:** Hovering a customer segment highlights corresponding geography bars.

## Story Points
A guided "Story" ties the 6 dashboards into a narrative: Overview → Campaign Deep-Dive → Customer Insights → ROI Diagnostics → Budget Recommendations → Forward-Looking Forecast — mirroring how this would be presented to stakeholders in a quarterly business review.
