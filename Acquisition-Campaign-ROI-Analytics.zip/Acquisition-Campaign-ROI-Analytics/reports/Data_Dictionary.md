# Data Dictionary

## `campaigns.csv` (5,200 rows)
| Column | Type | Description |
|---|---|---|
| campaign_id | string | Unique campaign identifier (`CMP######`) |
| campaign_name | string | Human-readable campaign name |
| channel | string | Acquisition channel (Google Ads, Facebook Ads, LinkedIn, Email Marketing, Organic Search, Referral, Affiliate) |
| campaign_type | string | Campaign objective (Brand Awareness, Lead Generation, Retargeting, etc.) |
| start_date / end_date | date | Campaign flight dates |
| budget | float | Allocated budget ($) |
| impressions | int | Total ad impressions |
| clicks | int | Total clicks |
| ctr | float | Click-through rate = clicks / impressions |
| cpc | float | Cost per click ($) |
| conversions | int | Number of conversions attributed to the campaign |
| conversion_rate | float | conversions / clicks |
| revenue | float | Attributed revenue ($) |
| cost | float | Actual spend ($) |
| roi | float | (revenue − cost) / cost |
| roas | float | revenue / cost |

## `customers.csv` (5,400 rows)
| Column | Type | Description |
|---|---|---|
| customer_id | string | Unique customer identifier (`CUST######`) |
| age | int | Customer age |
| gender | string | Male / Female / Non-binary |
| city / country | string | Customer location |
| device | string | Desktop / Mobile / Tablet |
| traffic_source | string | Acquisition channel at signup |
| customer_segment | string | New Acquisition / Growth / High Value / At Risk / Dormant |
| signup_date | date | Account signup date |
| purchase_date | date | First purchase date |
| lifetime_value | float | Cumulative customer LTV ($) |
| total_orders | int | Lifetime order count |

## `transactions.csv` (21,500 rows)
| Column | Type | Description |
|---|---|---|
| transaction_id | string | Unique transaction identifier (`TXN#######`) |
| customer_id | string | FK → customers |
| campaign_id | string | FK → campaigns (attribution) |
| purchase_amount | float | Gross transaction value ($) |
| profit | float | Net profit on the transaction ($) |
| order_date | date | Transaction date |
| refund | int (0/1) | Whether the transaction was refunded |
| coupon_used | int (0/1) | Whether a coupon/discount code was applied |

## `monthly_performance.csv` (245 rows)
Pre-aggregated month × channel rollup of impressions, clicks, conversions, cost, revenue, ROI, ROAS, and CAC — used to accelerate BI-layer queries and as the source for trend/forecast visuals.

---

## KPI Definitions

| KPI | Formula | Business Meaning |
|---|---|---|
| **CTR** | clicks / impressions | Ad creative/targeting relevance |
| **CPC** | cost / clicks | Efficiency of paid traffic acquisition |
| **Conversion Rate** | conversions / clicks | Landing page / offer effectiveness |
| **CAC** | cost / conversions | Cost to acquire one paying customer |
| **LTV** | AOV × purchase frequency × lifespan | Long-run value of a customer |
| **ROI** | (revenue − cost) / cost | Net return per dollar spent |
| **ROAS** | revenue / cost | Gross return per dollar spent |
| **Incremental ROI** | (ROI of test group) − (ROI of control/baseline group) | True lift attributable to a campaign, isolating organic/baseline demand |
