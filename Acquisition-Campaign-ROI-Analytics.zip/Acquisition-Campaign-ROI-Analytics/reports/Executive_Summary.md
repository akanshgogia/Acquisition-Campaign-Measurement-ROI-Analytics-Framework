# Executive Summary — Acquisition Campaign Measurement & ROI Analytics

**Prepared for:** VP of Growth Marketing
**Period covered:** Jan 2023 – Dec 2025
**Analyst:** Analytics Engineering Team

## Headline Numbers
- **Total ad + marketing spend analyzed:** ~$130M across 5,200 campaigns and 7 channels
- **Overall portfolio ROI:** positive across all channels, with wide variance by channel
- **Highest-ROI channels:** Referral, Organic Search, and Email Marketing — each driven by low incremental cost relative to attributed revenue
- **Highest-volume channels:** Google Ads and Facebook Ads — necessary for top-of-funnel scale, but with materially lower ROI per dollar than owned/earned channels

## Key Findings
1. **Channel is a statistically significant driver of ROI** (ANOVA, p < 0.001) — performance differences are structural, not noise.
2. **Conversion rate and CTR are the strongest positive predictors** of both campaign success and revenue in our Random Forest models (ROC-AUC ≈ 0.97, Revenue R² ≈ 0.93).
3. A meaningful subset of campaigns (concentrated in Facebook Ads and LinkedIn) show **negative ROI** despite material spend — strong candidates for pause or creative/targeting overhaul.
4. Customer segmentation (K-Means) surfaces a **compact high-LTV, low-frequency cluster** — a better fit for retention/upsell campaigns than broad acquisition spend.
5. **Geography and device** performance is uneven: certain countries and desktop traffic disproportionately drive lifetime value, suggesting geo-targeted budget weighting.

## Recommendations
| Action | Rationale | Expected Impact |
|---|---|---|
| Shift 10% of Facebook Ads / LinkedIn budget → Email Marketing & Referral | Highest marginal ROI per dollar | Meaningful projected profit uplift (see `06_budget_optimization.ipynb`) |
| Pause bottom-quartile ROI campaigns (see `underperforming_campaigns.csv`) | Loss-making at scale | Immediate cost savings, minimal revenue loss |
| Build a dedicated retention flow for the high-LTV/low-frequency cluster | Different growth lever than acquisition spend | Improved LTV:CAC ratio |
| Weight geo-targeting toward top-LTV countries | Concentrated returns | Higher blended ROAS |

## Future Improvements
- Incorporate true incrementality testing (holdout/control groups) rather than last-touch attribution to isolate causal lift.
- Extend the CLV model beyond linear regression to a probabilistic BG/NBD or Gamma-Gamma model for more accurate long-run value estimates.
- Automate the nightly `refresh_channel_performance_snapshot()` stored procedure and connect Power BI / Tableau via a live warehouse connection rather than flat-file extracts.

*Full technical detail, code, and reproducible analysis available in the accompanying notebooks and SQL scripts.*
