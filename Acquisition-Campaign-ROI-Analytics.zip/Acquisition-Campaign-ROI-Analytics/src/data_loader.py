"""
data_loader.py
--------------
Handles synthetic dataset generation (for portfolio/demo purposes) and
loading of raw CSV data into pandas DataFrames.

The `SyntheticDataGenerator` class produces four related datasets that
mimic a real SaaS company's marketing acquisition data warehouse:

    - campaigns.csv
    - customers.csv
    - transactions.csv
    - monthly_performance.csv

Author: Analytics Engineering Team
"""

from __future__ import annotations

import string
from datetime import timedelta
from pathlib import Path
from typing import Dict

import numpy as np
import pandas as pd

from src.utils import (
    calculate_conversion_rate,
    calculate_cpc,
    calculate_ctr,
    calculate_roas,
    calculate_roi,
    get_logger,
    load_config,
    resolve_path,
)

logger = get_logger(__name__)


class SyntheticDataGenerator:
    """Generates a realistic, internally-consistent synthetic dataset for
    a multi-channel acquisition marketing analytics project.

    All randomness is seeded for reproducibility.
    """

    CAMPAIGN_TYPES = [
        "Brand Awareness", "Lead Generation", "Retargeting", "Product Launch",
        "Seasonal Promo", "Free Trial Push", "Upsell", "Webinar Signup",
        "Content Syndication", "App Install",
    ]

    def __init__(self, config: Dict = None):
        self.config = config or load_config()
        self.seed = self.config["project"]["random_seed"]
        self.rng = np.random.default_rng(self.seed)

        gen_cfg = self.config["data_generation"]
        self.n_campaigns = gen_cfg["n_campaigns"]
        self.n_customers = gen_cfg["n_customers"]
        self.n_transactions = gen_cfg["n_transactions"]
        self.date_start = pd.Timestamp(gen_cfg["date_range"]["start"])
        self.date_end = pd.Timestamp(gen_cfg["date_range"]["end"])
        self.channels = gen_cfg["channels"]
        self.segments = gen_cfg["customer_segments"]
        self.devices = gen_cfg["devices"]
        self.countries = gen_cfg["countries"]

        # Channel-level behavioral parameters (drives realistic differences)
        self.channel_profiles = {
            "Google Ads":      dict(ctr=(0.02, 0.06), cvr=(0.02, 0.05), cpc=(0.8, 3.5), base_cost=(500, 15000)),
            "Facebook Ads":    dict(ctr=(0.01, 0.04), cvr=(0.015, 0.04), cpc=(0.5, 2.5), base_cost=(400, 12000)),
            "LinkedIn":        dict(ctr=(0.005, 0.02), cvr=(0.03, 0.07), cpc=(3.0, 9.0), base_cost=(800, 20000)),
            "Email Marketing": dict(ctr=(0.03, 0.09), cvr=(0.04, 0.09), cpc=(0.1, 0.4), base_cost=(100, 3000)),
            "Organic Search":  dict(ctr=(0.04, 0.10), cvr=(0.02, 0.05), cpc=(0.0, 0.05), base_cost=(50, 1500)),
            "Referral":        dict(ctr=(0.06, 0.12), cvr=(0.05, 0.10), cpc=(0.0, 0.10), base_cost=(50, 1000)),
            "Affiliate":       dict(ctr=(0.02, 0.05), cvr=(0.02, 0.06), cpc=(0.3, 1.5), base_cost=(200, 8000)),
        }

    # ------------------------------------------------------------------
    # Campaigns
    # ------------------------------------------------------------------
    def generate_campaigns(self) -> pd.DataFrame:
        logger.info("Generating campaigns.csv (%d rows)", self.n_campaigns)
        rng = self.rng
        n = self.n_campaigns

        channel_choices = rng.choice(self.channels, size=n,
                                      p=self._channel_weights())
        campaign_type = rng.choice(self.CAMPAIGN_TYPES, size=n)

        start_offsets = rng.integers(0, (self.date_end - self.date_start).days - 30, size=n)
        start_dates = [self.date_start + timedelta(days=int(o)) for o in start_offsets]
        durations = rng.integers(7, 60, size=n)
        end_dates = [s + timedelta(days=int(d)) for s, d in zip(start_dates, durations)]

        rows = []
        for i in range(n):
            channel = channel_choices[i]
            profile = self.channel_profiles[channel]

            budget = float(rng.uniform(*profile["base_cost"]))
            impressions = int(rng.integers(2_000, 500_000))
            ctr = float(rng.uniform(*profile["ctr"]))
            clicks = max(1, int(impressions * ctr * rng.uniform(0.85, 1.15)))
            cpc = float(rng.uniform(*profile["cpc"]))
            cost = round(min(budget, clicks * cpc), 2)
            cvr = float(rng.uniform(*profile["cvr"]))
            conversions = max(0, int(clicks * cvr * rng.uniform(0.8, 1.2)))

            avg_order_value = float(rng.uniform(35, 420))
            revenue = round(conversions * avg_order_value * rng.uniform(0.9, 1.3), 2)

            roi = calculate_roi(revenue, cost)
            roas = calculate_roas(revenue, cost)

            rows.append({
                "campaign_id": f"CMP{i+1:06d}",
                "campaign_name": f"{channel.split()[0]}_{campaign_type[i].replace(' ', '')}_{start_dates[i].strftime('%Y%m')}",
                "channel": channel,
                "campaign_type": campaign_type[i],
                "start_date": start_dates[i].date().isoformat(),
                "end_date": end_dates[i].date().isoformat(),
                "budget": round(budget, 2),
                "impressions": impressions,
                "clicks": clicks,
                "ctr": round(calculate_ctr(clicks, impressions), 4),
                "cpc": round(cpc, 2),
                "conversions": conversions,
                "conversion_rate": round(calculate_conversion_rate(conversions, clicks), 4),
                "revenue": revenue,
                "cost": cost,
                "roi": round(roi, 4),
                "roas": round(roas, 4),
            })

        df = pd.DataFrame(rows)
        return df

    def _channel_weights(self):
        # Skew traffic distribution so Google/Facebook dominate volume, like real life
        weights = {
            "Google Ads": 0.27, "Facebook Ads": 0.22, "LinkedIn": 0.10,
            "Email Marketing": 0.13, "Organic Search": 0.14,
            "Referral": 0.08, "Affiliate": 0.06,
        }
        return [weights[c] for c in self.channels]

    # ------------------------------------------------------------------
    # Customers
    # ------------------------------------------------------------------
    def generate_customers(self) -> pd.DataFrame:
        logger.info("Generating customers.csv (%d rows)", self.n_customers)
        rng = self.rng
        n = self.n_customers

        ages = rng.integers(18, 70, size=n)
        genders = rng.choice(["Male", "Female", "Non-binary"], size=n, p=[0.48, 0.48, 0.04])
        countries = rng.choice(self.countries, size=n)
        cities = [self._fake_city(c) for c in countries]
        devices = rng.choice(self.devices, size=n, p=[0.45, 0.48, 0.07])
        traffic_sources = rng.choice(self.channels, size=n, p=self._channel_weights())
        segments = rng.choice(self.segments, size=n, p=[0.30, 0.25, 0.15, 0.18, 0.12])

        signup_offsets = rng.integers(0, (self.date_end - self.date_start).days, size=n)
        signup_dates = [self.date_start + timedelta(days=int(o)) for o in signup_offsets]
        purchase_delay = rng.integers(0, 45, size=n)
        purchase_dates = [s + timedelta(days=int(d)) for s, d in zip(signup_dates, purchase_delay)]

        segment_ltv_mult = {
            "New Acquisition": (0.5, 1.0), "Growth": (1.0, 2.0), "High Value": (2.5, 6.0),
            "At Risk": (0.3, 0.9), "Dormant": (0.1, 0.4),
        }

        total_orders = []
        ltv = []
        for seg in segments:
            lo, hi = segment_ltv_mult[seg]
            base_ltv = rng.uniform(80, 500) * rng.uniform(lo, hi)
            ltv.append(round(base_ltv, 2))
            orders = max(1, int(rng.poisson(lam=hi * 2)))
            total_orders.append(orders)

        df = pd.DataFrame({
            "customer_id": [f"CUST{i+1:06d}" for i in range(n)],
            "age": ages,
            "gender": genders,
            "city": cities,
            "country": countries,
            "device": devices,
            "traffic_source": traffic_sources,
            "customer_segment": segments,
            "signup_date": [d.date().isoformat() for d in signup_dates],
            "purchase_date": [d.date().isoformat() for d in purchase_dates],
            "lifetime_value": ltv,
            "total_orders": total_orders,
        })
        return df

    @staticmethod
    def _fake_city(country: str) -> str:
        city_map = {
            "United States": ["Austin", "Chicago", "Seattle", "Denver", "Miami"],
            "United Kingdom": ["London", "Manchester", "Bristol", "Leeds"],
            "Canada": ["Toronto", "Vancouver", "Montreal", "Calgary"],
            "Australia": ["Sydney", "Melbourne", "Brisbane"],
            "Germany": ["Berlin", "Munich", "Hamburg"],
            "India": ["Bengaluru", "Mumbai", "Pune", "Hyderabad"],
            "Singapore": ["Singapore"],
        }
        options = city_map.get(country, ["Unknown"])
        return options[np.random.default_rng().integers(0, len(options))]

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------
    def generate_transactions(self, customers: pd.DataFrame,
                               campaigns: pd.DataFrame) -> pd.DataFrame:
        logger.info("Generating transactions.csv (%d rows)", self.n_transactions)
        rng = self.rng
        n = self.n_transactions

        cust_ids = customers["customer_id"].values
        camp_ids = campaigns["campaign_id"].values

        sampled_customers = rng.choice(cust_ids, size=n)
        sampled_campaigns = rng.choice(camp_ids, size=n)

        purchase_amount = rng.gamma(shape=2.2, scale=60, size=n).round(2)
        profit_margin = rng.uniform(0.15, 0.45, size=n)
        profit = (purchase_amount * profit_margin).round(2)

        camp_date_lookup = campaigns.set_index("campaign_id")["start_date"].to_dict()
        order_dates = []
        for cid in sampled_campaigns:
            base = pd.Timestamp(camp_date_lookup[cid])
            order_dates.append((base + timedelta(days=int(rng.integers(0, 45)))).date().isoformat())

        refund_flag = rng.choice([0, 1], size=n, p=[0.94, 0.06])
        coupon_used = rng.choice([0, 1], size=n, p=[0.72, 0.28])

        df = pd.DataFrame({
            "transaction_id": [f"TXN{i+1:07d}" for i in range(n)],
            "customer_id": sampled_customers,
            "campaign_id": sampled_campaigns,
            "purchase_amount": purchase_amount,
            "profit": profit,
            "order_date": order_dates,
            "refund": refund_flag,
            "coupon_used": coupon_used,
        })
        return df

    # ------------------------------------------------------------------
    # Monthly performance (aggregated)
    # ------------------------------------------------------------------
    def generate_monthly_performance(self, campaigns: pd.DataFrame) -> pd.DataFrame:
        logger.info("Generating monthly_performance.csv")
        df = campaigns.copy()
        df["start_date"] = pd.to_datetime(df["start_date"])
        df["month"] = df["start_date"].dt.to_period("M").astype(str)

        agg = df.groupby(["month", "channel"]).agg(
            total_impressions=("impressions", "sum"),
            total_clicks=("clicks", "sum"),
            total_conversions=("conversions", "sum"),
            total_cost=("cost", "sum"),
            total_revenue=("revenue", "sum"),
            campaigns_run=("campaign_id", "count"),
        ).reset_index()

        agg["ctr"] = (agg["total_clicks"] / agg["total_impressions"]).round(4)
        agg["conversion_rate"] = (agg["total_conversions"] / agg["total_clicks"]).round(4)
        agg["roi"] = ((agg["total_revenue"] - agg["total_cost"]) / agg["total_cost"]).round(4)
        agg["roas"] = (agg["total_revenue"] / agg["total_cost"]).round(4)
        agg["cac"] = (agg["total_cost"] / agg["total_conversions"].replace(0, np.nan)).round(2)

        return agg.sort_values(["month", "channel"]).reset_index(drop=True)

    # ------------------------------------------------------------------
    # Orchestration
    # ------------------------------------------------------------------
    def generate_all(self, output_dir: str | Path = None) -> Dict[str, pd.DataFrame]:
        output_dir = Path(output_dir) if output_dir else resolve_path("data/raw")
        output_dir.mkdir(parents=True, exist_ok=True)

        campaigns = self.generate_campaigns()
        customers = self.generate_customers()
        transactions = self.generate_transactions(customers, campaigns)
        monthly = self.generate_monthly_performance(campaigns)

        campaigns.to_csv(output_dir / "campaigns.csv", index=False)
        customers.to_csv(output_dir / "customers.csv", index=False)
        transactions.to_csv(output_dir / "transactions.csv", index=False)
        monthly.to_csv(output_dir / "monthly_performance.csv", index=False)

        logger.info("All datasets written to %s", output_dir)
        return {
            "campaigns": campaigns,
            "customers": customers,
            "transactions": transactions,
            "monthly_performance": monthly,
        }


# -------------------------------------------------------------------------
# Loading utilities (used by notebooks / downstream modules)
# -------------------------------------------------------------------------

def load_raw_data(data_dir: str | Path = None) -> Dict[str, pd.DataFrame]:
    """Load the four raw CSV datasets from disk into a dict of DataFrames."""
    data_dir = Path(data_dir) if data_dir else resolve_path("data/raw")
    return {
        "campaigns": pd.read_csv(data_dir / "campaigns.csv", parse_dates=["start_date", "end_date"]),
        "customers": pd.read_csv(data_dir / "customers.csv", parse_dates=["signup_date", "purchase_date"]),
        "transactions": pd.read_csv(data_dir / "transactions.csv", parse_dates=["order_date"]),
        "monthly_performance": pd.read_csv(data_dir / "monthly_performance.csv"),
    }


if __name__ == "__main__":
    cfg = load_config()
    generator = SyntheticDataGenerator(cfg)
    generator.generate_all()
