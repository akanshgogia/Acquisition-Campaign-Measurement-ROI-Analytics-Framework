"""
utils.py
--------
Shared utility functions used across the analytics pipeline: configuration
loading, logging setup, and common numerical helpers (CAC, ROAS, ROI, etc.).

Author: Analytics Engineering Team
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict

import yaml

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def load_config(config_path: str | Path = None) -> Dict[str, Any]:
    """Load the project YAML configuration file.

    Parameters
    ----------
    config_path : str | Path, optional
        Path to the config file. Defaults to ``config/config.yaml`` at the
        project root.

    Returns
    -------
    dict
        Parsed configuration dictionary.
    """
    if config_path is None:
        config_path = PROJECT_ROOT / "config" / "config.yaml"

    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_logger(name: str, level: str = "INFO") -> logging.Logger:
    """Return a configured logger instance.

    Parameters
    ----------
    name : str
        Logger name, typically ``__name__`` of the calling module.
    level : str
        Logging level (e.g. ``INFO``, ``DEBUG``).

    Returns
    -------
    logging.Logger
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    return logger


def resolve_path(relative_path: str | Path) -> Path:
    """Resolve a path relative to the project root."""
    return PROJECT_ROOT / relative_path


# -----------------------------------------------------------------------
# Core marketing-analytics metric helpers
# -----------------------------------------------------------------------

def calculate_roi(revenue: float, cost: float) -> float:
    """Return on Investment = (Revenue - Cost) / Cost."""
    if cost == 0:
        return 0.0
    return (revenue - cost) / cost


def calculate_roas(revenue: float, cost: float) -> float:
    """Return on Ad Spend = Revenue / Cost."""
    if cost == 0:
        return 0.0
    return revenue / cost


def calculate_ctr(clicks: int, impressions: int) -> float:
    """Click-Through Rate = Clicks / Impressions."""
    if impressions == 0:
        return 0.0
    return clicks / impressions


def calculate_cpc(cost: float, clicks: int) -> float:
    """Cost Per Click = Cost / Clicks."""
    if clicks == 0:
        return 0.0
    return cost / clicks


def calculate_conversion_rate(conversions: int, clicks: int) -> float:
    """Conversion Rate = Conversions / Clicks."""
    if clicks == 0:
        return 0.0
    return conversions / clicks


def calculate_cac(cost: float, new_customers: int) -> float:
    """Customer Acquisition Cost = Total Acquisition Cost / New Customers."""
    if new_customers == 0:
        return 0.0
    return cost / new_customers


def calculate_ltv(avg_order_value: float, purchase_frequency: float,
                   customer_lifespan_years: float) -> float:
    """Simplified Lifetime Value = AOV * Purchase Frequency * Lifespan (yrs)."""
    return avg_order_value * purchase_frequency * customer_lifespan_years
