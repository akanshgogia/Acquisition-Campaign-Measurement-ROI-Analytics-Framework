"""
model.py
--------
Machine learning models used to predict conversion probability, campaign
revenue, and customer lifetime value, plus shared evaluation utilities.

Author: Analytics Engineering Team
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (
    accuracy_score, confusion_matrix, f1_score, mean_absolute_error,
    mean_squared_error, precision_score, r2_score, recall_score, roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from src.utils import get_logger

logger = get_logger(__name__)


@dataclass
class RegressionResult:
    model: object
    mae: float
    rmse: float
    r2: float
    feature_importance: pd.Series = field(default=None)


@dataclass
class ClassificationResult:
    model: object
    accuracy: float
    precision: float
    recall: float
    f1: float
    roc_auc: float
    confusion: np.ndarray
    feature_importance: pd.Series = field(default=None)


class CampaignSuccessClassifier:
    """Predicts whether a campaign will be 'successful' (ROI above the
    median) using Random Forest / Logistic Regression."""

    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.scaler = StandardScaler()

    def prepare_features(self, campaigns: pd.DataFrame) -> pd.DataFrame:
        df = campaigns.copy()
        df["success"] = (df["roi"] > df["roi"].median()).astype(int)
        df = pd.get_dummies(df, columns=["channel", "campaign_type"], drop_first=True)
        feature_cols = [c for c in df.columns if c not in [
            "campaign_id", "campaign_name", "start_date", "end_date",
            "roi", "roas", "revenue", "success"
        ] and df[c].dtype != object]
        return df, feature_cols

    def train_logistic(self, campaigns: pd.DataFrame) -> ClassificationResult:
        df, feature_cols = self.prepare_features(campaigns)
        X, y = df[feature_cols], df["success"]
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=y)

        X_train_s = self.scaler.fit_transform(X_train)
        X_test_s = self.scaler.transform(X_test)

        clf = LogisticRegression(max_iter=1000, random_state=self.random_state)
        clf.fit(X_train_s, y_train)
        preds = clf.predict(X_test_s)
        probs = clf.predict_proba(X_test_s)[:, 1]

        return ClassificationResult(
            model=clf,
            accuracy=accuracy_score(y_test, preds),
            precision=precision_score(y_test, preds),
            recall=recall_score(y_test, preds),
            f1=f1_score(y_test, preds),
            roc_auc=roc_auc_score(y_test, probs),
            confusion=confusion_matrix(y_test, preds),
        )

    def train_random_forest(self, campaigns: pd.DataFrame,
                             n_estimators: int = 200) -> ClassificationResult:
        df, feature_cols = self.prepare_features(campaigns)
        X, y = df[feature_cols], df["success"]
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=y)

        clf = RandomForestClassifier(n_estimators=n_estimators, max_depth=8,
                                      random_state=self.random_state)
        clf.fit(X_train, y_train)
        preds = clf.predict(X_test)
        probs = clf.predict_proba(X_test)[:, 1]

        importance = pd.Series(clf.feature_importances_, index=feature_cols).sort_values(ascending=False)

        return ClassificationResult(
            model=clf,
            accuracy=accuracy_score(y_test, preds),
            precision=precision_score(y_test, preds),
            recall=recall_score(y_test, preds),
            f1=f1_score(y_test, preds),
            roc_auc=roc_auc_score(y_test, probs),
            confusion=confusion_matrix(y_test, preds),
            feature_importance=importance,
        )


class RevenuePredictor:
    """Predicts campaign revenue using Linear Regression and Random Forest."""

    def __init__(self, random_state: int = 42):
        self.random_state = random_state

    def _features(self, campaigns: pd.DataFrame):
        df = pd.get_dummies(campaigns.copy(), columns=["channel", "campaign_type"], drop_first=True)
        feature_cols = [c for c in df.columns if c not in [
            "campaign_id", "campaign_name", "start_date", "end_date", "revenue"
        ] and df[c].dtype != object]
        return df, feature_cols

    def train_random_forest(self, campaigns: pd.DataFrame,
                             n_estimators: int = 200) -> RegressionResult:
        df, feature_cols = self._features(campaigns)
        X, y = df[feature_cols], df["revenue"]
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state)

        reg = RandomForestRegressor(n_estimators=n_estimators, max_depth=10,
                                     random_state=self.random_state)
        reg.fit(X_train, y_train)
        preds = reg.predict(X_test)

        importance = pd.Series(reg.feature_importances_, index=feature_cols).sort_values(ascending=False)

        return RegressionResult(
            model=reg,
            mae=mean_absolute_error(y_test, preds),
            rmse=mean_squared_error(y_test, preds) ** 0.5,
            r2=r2_score(y_test, preds),
            feature_importance=importance,
        )


class CustomerSegmentation:
    """K-Means clustering for customer segmentation based on RFM-style
    behavioral features."""

    def __init__(self, n_clusters: int = 4, random_state: int = 42):
        self.n_clusters = n_clusters
        self.random_state = random_state
        self.scaler = StandardScaler()
        self.model = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)

    def fit_predict(self, customers: pd.DataFrame,
                     feature_cols=("lifetime_value", "total_orders", "age")) -> pd.Series:
        X = self.scaler.fit_transform(customers[list(feature_cols)])
        labels = self.model.fit_predict(X)
        return pd.Series(labels, index=customers.index, name="cluster")


def calculate_clv_regression(customers: pd.DataFrame) -> RegressionResult:
    """Simple linear regression predicting LTV from age, total_orders."""
    df = customers.copy()
    X = df[["age", "total_orders"]]
    y = df["lifetime_value"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    reg = LinearRegression()
    reg.fit(X_train, y_train)
    preds = reg.predict(X_test)

    return RegressionResult(
        model=reg,
        mae=mean_absolute_error(y_test, preds),
        rmse=mean_squared_error(y_test, preds) ** 0.5,
        r2=r2_score(y_test, preds),
    )
