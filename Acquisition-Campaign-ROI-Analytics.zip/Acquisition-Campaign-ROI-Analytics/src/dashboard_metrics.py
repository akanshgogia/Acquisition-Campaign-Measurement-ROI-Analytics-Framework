"""
dashboard_metrics.py
---------------------
Computes summarized KPI tables that feed the Power BI / Tableau dashboards
and the executive reporting layer. Each function returns a tidy DataFrame
ready to export to CSV/Parquet for BI consumption.

Author: Analytics Engineering Team
"""

from __future__ import annotations

import pandas as pd

from src.utils import calculate_cac, get_logger

logger = get_logger(__name__)


def channel_summary(campaigns: pd.DataFrame) -> pd.DataFrame:
    """One row per channel: spend, revenue, ROI, ROAS, CAC, conversions."""
    agg = campaigns.groupby("channel").agg(
        total_budget=("budget", "sum"),
        total_cost=("cost", "sum"),
        total_revenue=("revenue", "sum"),
        total_impressions=("impressions", "sum"),
        total_clicks=("clicks", "sum"),
        total_conversions=("conversions", "sum"),
        avg_roi=("roi", "mean"),
        avg_roas=("roas", "mean"),
        campaigns_run=("campaign_id", "count"),
    ).reset_index()
    agg["cac"] = agg.apply(lambda r: calculate_cac(r["total_cost"], r["total_conversions"]), axis=1)
    agg["overall_roi"] = (agg["total_revenue"] - agg["total_cost"]) / agg["total_cost"]
    return agg.sort_values("overall_roi", ascending=False).reset_index(drop=True)


def top_campaigns(campaigns: pd.DataFrame, n: int = 20, by: str = "roi") -> pd.DataFrame:
    return campaigns.sort_values(by, ascending=False).head(n).reset_index(drop=True)


def underperforming_campaigns(campaigns: pd.DataFrame, roi_threshold: float = 0.0) -> pd.DataFrame:
    """Campaigns flagged for pausing/review (ROI below threshold)."""
    return campaigns[campaigns["roi"] < roi_threshold].sort_values("roi").reset_index(drop=True)


def segment_performance(customers: pd.DataFrame) -> pd.DataFrame:
    return customers.groupby("customer_segment").agg(
        customers=("customer_id", "count"),
        avg_ltv=("lifetime_value", "mean"),
        total_ltv=("lifetime_value", "sum"),
        avg_orders=("total_orders", "mean"),
    ).reset_index().sort_values("total_ltv", ascending=False)


def geo_performance(customers: pd.DataFrame) -> pd.DataFrame:
    return customers.groupby("country").agg(
        customers=("customer_id", "count"),
        avg_ltv=("lifetime_value", "mean"),
        total_ltv=("lifetime_value", "sum"),
    ).reset_index().sort_values("total_ltv", ascending=False)


def device_performance(customers: pd.DataFrame) -> pd.DataFrame:
    return customers.groupby("device").agg(
        customers=("customer_id", "count"),
        avg_ltv=("lifetime_value", "mean"),
    ).reset_index().sort_values("avg_ltv", ascending=False)


def budget_reallocation_recommendation(campaigns: pd.DataFrame) -> pd.DataFrame:
    """Suggests reallocating budget from bottom-quartile ROI channels to
    top-quartile ROI channels, holding total spend constant."""
    summary = channel_summary(campaigns)
    summary["roi_rank"] = summary["overall_roi"].rank(ascending=False)
    median_roi = summary["overall_roi"].median()

    summary["recommendation"] = summary["overall_roi"].apply(
        lambda x: "Increase Budget" if x > median_roi * 1.15
        else ("Decrease Budget" if x < median_roi * 0.85 else "Maintain")
    )
    return summary[["channel", "total_cost", "total_revenue", "overall_roi",
                     "cac", "recommendation"]]


def export_all(data: dict, output_dir: str = "data/processed") -> None:
    """Computes and writes all KPI tables to the processed data directory."""
    from pathlib import Path
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    channel_summary(data["campaigns"]).to_csv(out / "channel_summary.csv", index=False)
    top_campaigns(data["campaigns"]).to_csv(out / "top_campaigns.csv", index=False)
    underperforming_campaigns(data["campaigns"]).to_csv(out / "underperforming_campaigns.csv", index=False)
    segment_performance(data["customers"]).to_csv(out / "segment_performance.csv", index=False)
    geo_performance(data["customers"]).to_csv(out / "geo_performance.csv", index=False)
    device_performance(data["customers"]).to_csv(out / "device_performance.csv", index=False)
    budget_reallocation_recommendation(data["campaigns"]).to_csv(out / "budget_recommendation.csv", index=False)
    logger.info("KPI tables exported to %s", out)
