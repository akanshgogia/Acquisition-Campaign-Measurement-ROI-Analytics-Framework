"""
preprocessing.py
-----------------
Data cleaning, validation, and feature-engineering routines applied to the
raw acquisition/campaign datasets before analysis or modeling.

Author: Analytics Engineering Team
"""

from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd

from src.utils import get_logger

logger = get_logger(__name__)


class DataPreprocessor:
    """Cleans and enriches the raw campaign/customer/transaction datasets."""

    def __init__(self, data: Dict[str, pd.DataFrame]):
        self.campaigns = data["campaigns"].copy()
        self.customers = data["customers"].copy()
        self.transactions = data["transactions"].copy()
        self.monthly = data["monthly_performance"].copy()

    # ------------------------------------------------------------------
    def clean_campaigns(self) -> pd.DataFrame:
        df = self.campaigns
        before = len(df)

        df = df.drop_duplicates(subset="campaign_id")
        df = df[(df["clicks"] <= df["impressions"]) & (df["impressions"] > 0)]
        df = df[df["cost"] >= 0]
        df["start_date"] = pd.to_datetime(df["start_date"])
        df["end_date"] = pd.to_datetime(df["end_date"])
        df["duration_days"] = (df["end_date"] - df["start_date"]).dt.days.clip(lower=1)

        # Winsorize extreme ROI/ROAS outliers (top/bottom 0.5%) for modeling stability
        for col in ["roi", "roas"]:
            lo, hi = df[col].quantile([0.005, 0.995])
            df[col] = df[col].clip(lo, hi)

        removed = before - len(df)
        logger.info("clean_campaigns: removed %d invalid rows (%.2f%%)",
                    removed, 100 * removed / before)
        self.campaigns = df.reset_index(drop=True)
        return self.campaigns

    # ------------------------------------------------------------------
    def clean_customers(self) -> pd.DataFrame:
        df = self.customers
        df = df.drop_duplicates(subset="customer_id")
        df = df[(df["age"] >= 16) & (df["age"] <= 90)]
        df["signup_date"] = pd.to_datetime(df["signup_date"])
        df["purchase_date"] = pd.to_datetime(df["purchase_date"])
        df["days_to_first_purchase"] = (df["purchase_date"] - df["signup_date"]).dt.days.clip(lower=0)
        df["lifetime_value"] = df["lifetime_value"].clip(lower=0)
        self.customers = df.reset_index(drop=True)
        return self.customers

    # ------------------------------------------------------------------
    def clean_transactions(self) -> pd.DataFrame:
        df = self.transactions
        df = df.drop_duplicates(subset="transaction_id")
        df = df[df["purchase_amount"] > 0]
        df["order_date"] = pd.to_datetime(df["order_date"])
        df["net_revenue"] = np.where(df["refund"] == 1, 0, df["purchase_amount"])
        self.transactions = df.reset_index(drop=True)
        return self.transactions

    # ------------------------------------------------------------------
    def build_master_table(self) -> pd.DataFrame:
        """Joins transactions -> campaigns -> customers into a single
        analysis-ready fact table."""
        txn = self.transactions.merge(
            self.campaigns[["campaign_id", "channel", "campaign_type", "roi", "roas"]],
            on="campaign_id", how="left"
        )
        master = txn.merge(
            self.customers[["customer_id", "age", "gender", "country", "device",
                            "customer_segment", "lifetime_value"]],
            on="customer_id", how="left"
        )
        logger.info("build_master_table: %d rows, %d columns", *master.shape)
        return master

    def run_all(self) -> Dict[str, pd.DataFrame]:
        self.clean_campaigns()
        self.clean_customers()
        self.clean_transactions()
        master = self.build_master_table()
        return {
            "campaigns": self.campaigns,
            "customers": self.customers,
            "transactions": self.transactions,
            "monthly_performance": self.monthly,
            "master": master,
        }
